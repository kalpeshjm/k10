
/*Aim:C/C++ Program to assign nice values to processes and dynamically monitor them.*/

#include<stdio.h>
#include<stdlib.h>
#include<sys/resource.h>
#include<unistd.h>

int main()
{
	int rc,nc;
	int ch;
	
	while(1)
	{
		system("ps axl");
		printf("\ncurrent nice value can be checked from above table");
		printf("\ncurrent priority of process %d is %d",getpid(),getpriority(PRIO_PROCESS,0));
		printf("\nEnter new nice value (bet -20 to 20)");
		scanf("%d",&nc);
		rc=setpriority(PRIO_PROCESS,0,nc);

		if(0!=rc)
		{
			perror("setpriority"); 
		}
		sleep(2);

		printf("\nModified nice value of the process %d is : %d ",getpid(),
		getpriority(PRIO_PROCESS,0));
		printf("\n Do you want to continue(press 1 to continue and 0 to stop):");

		scanf("%d",&ch);

		if(ch==0)
			exit(0);
	}
	return 0;
}
