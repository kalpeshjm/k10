class Assembler
{
	public static void main(String args[])
	{
		String a[][]={
				{"","START","101",""},
				{"","MOVER","BREG","ONE"},
				{"","MOVEM","BREG","TERM"},
				{"AGAIN","MULT","BREG","TERM"},
				{"","MOVER","CREG","TERM"},
				{"","ADD","CREG","N"},
				{"","MOVEM","CREG","TERM"},
				{"N","DS","2",""},
				{"RESULT","DS","2",""},
				{"ONE","DC","1",""},
				{"TERM","DS","1",""},
				{"","END","",""}
				};
				
		String st[][] = new String[10][5];
		
		int lc = Integer.parseInt(a[0][2]);
		
		int i,cnt=0,l;
		
		for(i=1;i<11;i++)
		{
			if(a[i][0] != "")
			{
				st[cnt][0] = a[i][0];
				st[cnt][1] = Integer.toString(lc);
				cnt++;
				if(a[i][1] == "DS")
				{
					l = Integer.parseInt(a[i][2]);
					lc = lc + l;
				}else
				{
					lc++;
				}
			}else
			{
				lc++;
			}
		}
		
		System.out.println("*******  Symbol Table  *******\nSymbol\tAddress");
		for(i=0;i<cnt;i++)
		{
			System.out.println(st[i][0]+"\t"+st[i][1]);
		}
		
		//////////////////////////////////////////////////////////////////////////////
		
		
		String inst[] = {"STOP","ADD","SUB","MULT","DIV","MOVER","MOVEM","READ","PRINT"};
		String reg[] = {"AREG","BREG","CREG","DREG"};
		int op[][] = new int[15][3];
		
		int cnt1=0,k,j;
		
		for(i=1;i<11;i++)
		{
			k=1;
			for(j=0;j<9;j++)
			{
				if(a[i][1].equalsIgnoreCase(inst[j]))
					op[cnt1][0] = j;
				else 
				if(a[i][1].equalsIgnoreCase("DS"))
					k = Integer.parseInt(a[i][2]);
				else
				if(a[i][1].equalsIgnoreCase("DC"))
					op[cnt1][2] = Integer.parseInt(a[i][2]);
			}
			
			for(j=0;j<4;j++)
			{
				if(a[i][2].equalsIgnoreCase(reg[j]))
					op[cnt1][1] = j;
			}
			
			for(j=0;j<cnt;j++)
			{
				if(a[i][3].equalsIgnoreCase(st[j][0]))
					op[cnt1][2] = Integer.parseInt(st[j][1]);
			}
			
			cnt1 = cnt1+k;
		}
		
		System.out.println("*******  Machine Code  *******");
		lc = Integer.parseInt(a[0][2]);
		for(i=0;i<12;i++)
		{
			System.out.println((lc++)+"\t"+op[i][0]+" "+op[i][1]+" "+op[i][2]);
		}
		
	}
}

