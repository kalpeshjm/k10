import math_dll.Maths;

class DLL_implement
{	
	public static void main(String args[])
	{
		Maths m = new Maths();
		System.out.println("Value of abs(-3) = "+m.abs(-3));
		
		System.out.println("Square of 5 = "+m.square(5));
		
		System.out.println("Value of sin(60) = "+m.sin(60));
		
		System.out.println("Value of cos(60) = "+m.cos(60));
		
		System.out.println("Value of tan(60) = "+m.tan(60));
	}
}
