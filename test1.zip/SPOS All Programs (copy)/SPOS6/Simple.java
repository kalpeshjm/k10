import java.io.*; 
class Simple
{
	public static void main(String args[])
	{
		double a;
		long b = 10;
		System.out.println("This is sample file for test");
	}
}
