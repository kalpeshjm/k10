import java.util.Scanner;

class Banker
{

	int need[][],allocate[][],max[][],avail[],np,nr;
	
	void input()
	{
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter no of processes and resources : ");

		np = sc.nextInt();
		nr = sc.nextInt();
		
		need = new int[np][nr];
		allocate = new int[np][nr];
		max = new int[np][nr];
		avail = new int[nr];
		
		int i,j;
		
		System.out.println("Enter allocation matrix :");
		for(i=0; i<np; i++)
		{
			for(j=0; j<nr; j++)
				allocate[i][j]=sc.nextInt();
		}
		
		System.out.println("Enter max claim matrx :");
		for(i=0; i<np; i++)
		{
			for(j=0; j<nr; j++)
				max[i][j]=sc.nextInt();
		}
		
		System.out.println("Enter available maxtix : ");
		for(i=0; i<nr; i++)
		{
			avail[i]=sc.nextInt();
		}
		
		sc.close();
		//show(allocate);
		//show(max);
	}

	void calc_need()
	{
		for(int i=0; i<np; i++)
		{
			for(int j=0; j<nr; j++)
			{
				need[i][j] = max[i][j] - allocate[i][j];
			}
		}
	}

	boolean check(int i)
	{
		for(int j=0; j<nr; j++)
		{
			if(avail[j] < need[i][j])
				return false;			
		}		
		return true;
	}


	void isSafe()
	{
		input();
		calc_need();
		System.out.println("\nNeed matrix : \n");
		for(int l=0; l<np; l++)
		{
			for(int n=0; n<nr; n++)
			{
				System.out.print(need[l][n]+" ");
			}

			System.out.println("\n");
		}
		
		
		System.out.println("\nNeed matrix : \tAvailable matrix\n");
		
		boolean done[] = new boolean[np];
		
		int j=0;
		
		while(j<np)
		{
			boolean allocated = false;
			
			for(int i=0; i<np; i++)
			{
				if(!done[i] && check(i))
				{
					for(int k=0; k<nr; k++)
					{
						avail[k] = avail[k] + allocate[0][k];
					}
					
					show(need,avail,i);

					done[i]=allocated=true;
					System.out.println("Allocated process : "+i);
					j++;
					break;
				}
			}
			
			if(!allocated)
			{ break;}	
		}
		
		if(j == np)
			System.out.println("All processes are allocated safely.");
		else
			System.out.println("All processes unable to allocate safely.");
		
	}

	void show(int a[][],int b[],int i)
	{
		for(int j=0; j<nr; j++)
		{
			System.out.print(a[i][j]+" ");
		}
		System.out.print("\t\t");
		for(int j=0; j<nr; j++)
		{
			System.out.print(b[j]+" ");
		}
		System.out.println("\n");
	}
	
	public static void main(String args[])
	{
		new Banker().isSafe();
	}

}
