lex ass9.l
yacc -d ass9.y
gcc lex.yy.c y.tab.c -ll
./a.out
